module.exports = require("bindings")("addon");

